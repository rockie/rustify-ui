import {test, expect, type Page} from '@playwright/test';
import {PNG} from 'pngjs';

const report = (page: Page) => page.evaluate(() => (window as any).__utility_lab.gpuReport('scope-a'));
async function ready(page: Page) {
  await page.goto('./');
  await expect(page.locator('#status')).toHaveAttribute('data-status', 'ready');
  await page.getByTestId('utility-gpu').scrollIntoViewIfNeeded();
  await expect(page.locator('#gpu-status')).toHaveText('GPU ready');
  await expect.poll(async () => (await report(page))?.button.drawn_revision).toBe(0);
}
async function apply(page: Page, button: string[], others: string[][] = [[], [], []], partial = false, disabled = false) {
  const revision = await page.evaluate(async ({button, others, partial, disabled}) => {
    const api = (window as any).__utility_lab;
    const result = await api.gpuApply('scope-a', [others[0], button, others[1], others[2]], partial, disabled);
    document.getElementById('scope-a-sample')!.className = `sample ${button.join(' ')}`;
    for (const [id, base, values] of [['scope-a-frame', 'preview-content', others[0]], ['scope-a-text', 'sample-text', others[1]], ['scope-a-swatch', 'sample-swatch', others[2]]] as const) {
      document.getElementById(id)!.className = `${base} ${values.join(' ')}`;
    }
    return result.revision;
  }, {button, others, partial, disabled});
  await expect.poll(async () => (await report(page))?.button.attempted_revision).toBe(revision);
  return revision;
}
async function drawn(page: Page, revision: number, slot = 'button') {
  await expect.poll(async () => (await report(page))?.[slot].drawn_revision).toBe(revision);
  return report(page);
}
const pixel = (png: PNG, x: number, y: number) => Array.from(png.data.subarray((Math.floor(y) * png.width + Math.floor(x)) * 4, (Math.floor(y) * png.width + Math.floor(x)) * 4 + 4));

test('applied utility dependencies drive DOM and GPU and survive an installation failure', async ({page}, info) => {
  const errors: string[] = [], failed: string[] = [], violations: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('requestfailed', request => failed.push(request.url()));
  await ready(page);
  await page.exposeFunction('recordApplyViolation', (directive: string) => violations.push(directive));
  await page.evaluate(() => {
    document.addEventListener('securitypolicyviolation', event => (window as any).recordApplyViolation(event.violatedDirective));
    const api = (window as any).__utility_lab;
    api.dispose('scope-a');
    api.mount('scope-a', 10000, '@utility base-card { @apply w-[137px] h-[72px] bg-[#123456] text-[#ffffff]; } @utility applied-card { @apply base-card p-[7px] border-2 border-[#abcdef]; } @utility next-card { @apply w-[179px] h-[72px] bg-[#abcdef]; } @tailwind utilities;');
  });
  await expect(page.locator('#gpu-status')).toHaveText('GPU ready');
  const first = await apply(page, ['applied-card']);
  const before = await drawn(page, first);
  expect(before.button.status).toBe('applied');
  expect(before.button.geometry.slice(2)).toEqual([137, 72]);
  expect(before.button.computed.padding).toEqual([7, 7, 7, 7]);
  expect(before.button.computed.border_widths).toEqual([2, 2, 2, 2]);
  const sample = page.locator('#scope-a-sample');
  await expect(sample).toHaveCSS('width', '137px');
  await expect(sample).toHaveCSS('background-color', 'rgb(18, 52, 86)');
  const png = PNG.sync.read(await page.getByTestId('utility-gpu').screenshot());
  const [x, y, width] = before.button.geometry;
  expect(pixel(png, x + 8, y + 8).slice(0, 3)).toEqual([18, 52, 86]);
  expect(pixel(png, x + width / 2 + 1, y + 1).slice(0, 3)).toEqual([171, 205, 239]);
  const failure = await page.evaluate(async () => {
    const original = CSSStyleSheet.prototype.replaceSync;
    CSSStyleSheet.prototype.replaceSync = function() { throw new DOMException('injected @apply install failure', 'SyntaxError'); };
    try { await (window as any).__utility_lab.gpuApply('scope-a', [[], ['next-card'], [], []]); }
    catch (error) { return JSON.parse(String(error)); }
    finally { CSSStyleSheet.prototype.replaceSync = original; }
  });
  expect(failure.kind).toBe('install');
  const retained = await report(page);
  expect(retained.button.applied_revision).toBe(first);
  expect(retained.button.drawn_revision).toBe(first);
  expect(retained.button.computed).toEqual(before.button.computed);
  await expect(sample).toHaveCSS('width', '137px');
  const next = await apply(page, ['next-card']);
  const recovered = await drawn(page, next);
  expect(next).toBe(first + 1);
  expect(recovered.button.geometry.slice(2)).toEqual([179, 72]);
  await expect(sample).toHaveCSS('width', '179px');
  await expect(sample).toHaveCSS('background-color', 'rgb(171, 205, 239)');
  expect(errors).toEqual([]); expect(failed).toEqual([]); expect(violations).toEqual([]);
  await info.attach('Applied dependencies and recovery', {body: JSON.stringify({before, retained, recovered}, null, 2), contentType: 'application/json'});
  await page.screenshot({path: info.outputPath('applied-utility.png'), fullPage: true});
});

test('GPU draws compiled colors, geometry and real font glyphs alongside scoped DOM', async ({page}, info) => {
  const errors: string[] = [], failed: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('requestfailed', request => failed.push(request.url()));
  await ready(page);
  const revision = await apply(page, ['w-[137px]', 'h-[72px]', 'bg-[#123456]', 'text-[#ffffff]', 'rounded-[8px]', 'p-[7px]', 'border-2', 'border-[#abcdef]']);
  const state = await drawn(page, revision);
  expect(state.button.status).toBe('applied');
  expect(state.button.computed.padding).toEqual([7, 7, 7, 7]);
  expect(state.button.computed.border_widths).toEqual([2, 2, 2, 2]);
  expect(state.button.geometry.slice(2)).toEqual([137, 72]);
  expect(state.button.computed.font.resource_path).toContain('IBMPlexSans');
  await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '137px');
  await expect(page.locator('#scope-a-sample')).toHaveCSS('padding-top', '7px');
  const pixels = await page.getByTestId('utility-gpu').screenshot();
  await info.attach('GPU canvas pixels', {body: pixels, contentType: 'image/png'});
  await info.attach('GPU actual drawn report', {body: JSON.stringify(state, null, 2), contentType: 'application/json'});
  const png = PNG.sync.read(pixels);
  const [x, y, w, h] = state.button.geometry;
  expect(pixel(png, x + 8, y + 8).slice(0, 3)).toEqual([18, 52, 86]);
  const border = pixel(png, x + w / 2 + 1, y + 1);
  expect(border.slice(0, 3)).toEqual([171, 205, 239]);
  let whiteInk = 0;
  for (let py = y + 12; py < y + h - 12; py++) for (let px = x + 8; px < x + w - 8; px++) {
    if (pixel(png, px, py).slice(0, 3).every(value => value > 220)) whiteInk++;
  }
  expect(whiteInk).toBeGreaterThan(15);
  expect(errors).toEqual([]); expect(failed).toEqual([]);
  await page.screenshot({path: info.outputPath('desktop.png'), fullPage: true});
  await page.setViewportSize({width: 390, height: 844});
  await page.getByTestId('utility-gpu').scrollIntoViewIfNeeded();
  await page.evaluate(async () => { await document.fonts.ready; await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))); });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.screenshot({path: info.outputPath('mobile.png'), fullPage: true});
});

test('CSS functions resolve runtime candidates once and drive actual DOM and GPU pixels', async ({page}, info) => {
  const errors: string[] = [], failed: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('requestfailed', request => failed.push(request.url()));
  await ready(page);
  const classes = ['w-[--theme(--missing,128px)]', 'h-[theme(spacing.12)]', 'p-[theme(spacing.2)]',
    'bg-[color:--alpha(#123456_/_1)]', 'text-[color:--alpha(#ffffff_/_1)]',
    'rounded-[--theme(--missing,8px)]', 'border-[length:--theme(--missing,2px)]',
    'border-[color:--alpha(#abcdef_/_1)]'];
  const revision = await apply(page, classes);
  const state = await drawn(page, revision);
  expect(state.button.status).toBe('applied');
  expect(state.button.geometry.slice(2)).toEqual([128, 48]);
  expect(state.button.computed.padding).toEqual([8, 8, 8, 8]);
  expect(state.button.computed.border_widths).toEqual([2, 2, 2, 2]);
  const sample = page.locator('#scope-a-sample');
  await expect(sample).toHaveCSS('width', '128px');
  await expect(sample).toHaveCSS('height', '48px');
  await expect(sample).toHaveCSS('padding-top', '8px');
  await expect(sample).toHaveCSS('background-color', 'rgb(18, 52, 86)');
  const png = PNG.sync.read(await page.getByTestId('utility-gpu').screenshot());
  const [x, y, width] = state.button.geometry;
  expect(pixel(png, x + 8, y + 8).slice(0, 3)).toEqual([18, 52, 86]);
  expect(pixel(png, x + width / 2 + 1, y + 1).slice(0, 3)).toEqual([171, 205, 239]);
  const repeated = await page.evaluate(async classes => {
    const original = Worker.prototype.postMessage;
    let prepares = 0;
    Worker.prototype.postMessage = function(this: Worker, message: any, options?: any) {
      if (message.operation === 'prepare') prepares++;
      return original.call(this, message, options);
    };
    try { return {report: await (window as any).__utility_lab.ensure('scope-a', classes), prepares}; }
    finally { Worker.prototype.postMessage = original; }
  }, classes);
  expect(repeated.report.revision).toBe(revision);
  expect(repeated.prepares).toBe(0);
  expect(errors).toEqual([]); expect(failed).toEqual([]);
  await info.attach('CSS functions drawn GPU report', {body: JSON.stringify(state, null, 2), contentType: 'application/json'});
  await page.screenshot({path: info.outputPath('gpu-css-functions.png'), fullPage: true});
});

test('CSS-native utilities drive scoped DOM and GPU while nested branches retain the drawn style', async ({page}, info) => {
  const errors: string[] = [], failed: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('requestfailed', request => failed.push(request.url()));
  await ready(page);
  await page.evaluate(() => {
    const api = (window as any).__utility_lab;
    api.dispose('scope-a');
    api.mount('scope-a', 10000, '@theme { --size-card:137px; --color-card:#123456; } @utility fixture-* { width:--value(--size,[length]); height:72px; background-color:--modifier(--color,[color]); color:white; } @utility nested-card { &:hover { border:2px solid #abcdef; } } @tailwind utilities;');
  });
  await expect(page.locator('#gpu-status')).toHaveText('GPU ready');
  const first = await apply(page, ['fixture-card/card']);
  const before = await drawn(page, first);
  expect(before.button.status).toBe('applied');
  expect(before.button.geometry.slice(2)).toEqual([137, 72]);
  const sample = page.locator('#scope-a-sample');
  await expect(sample).toHaveCSS('width', '137px');
  await expect(sample).toHaveCSS('background-color', 'rgb(18, 52, 86)');
  const png = PNG.sync.read(await page.getByTestId('utility-gpu').screenshot());
  const [x, y] = before.button.geometry;
  expect(pixel(png, x + 8, y + 8).slice(0, 3)).toEqual([18, 52, 86]);
  await page.screenshot({path: info.outputPath('custom-utility.png'), fullPage: true});
  const next = await apply(page, ['fixture-card/card', 'nested-card']);
  await sample.hover();
  await expect(sample).toHaveCSS('border-top-color', 'rgb(171, 205, 239)');
  const after = await report(page);
  expect(after.button.status).toBe('rejected');
  expect(after.button.attempted_revision).toBe(next);
  expect(after.button.applied_revision).toBe(first);
  expect(after.button.drawn_revision).toBe(first);
  expect(after.button.computed).toEqual(before.button.computed);
  expect(errors).toEqual([]); expect(failed).toEqual([]);
  await info.attach('Custom utility DOM and retained GPU report', {body: JSON.stringify({before, after}, null, 2), contentType: 'application/json'});
});

test('authored custom variants apply DOM hover and preserve the last drawn GPU style on rejection', async ({page}, info) => {
  const errors: string[] = [], failed: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('requestfailed', request => failed.push(request.url()));
  await ready(page);
  await page.evaluate(() => {
    const api = (window as any).__utility_lab;
    api.dispose('scope-a');
    api.mount('scope-a', 10000, '@custom-variant intent (&:hover); @utility application-card { width:137px; height:72px; background-color:#123456; @variant intent { border:2px solid #abcdef; } } @tailwind utilities;');
  });
  await expect(page.locator('#gpu-status')).toHaveText('GPU ready');
  const first = await apply(page, ['w-[137px]', 'h-[72px]', 'bg-[#123456]']);
  const before = await drawn(page, first);
  const next = await apply(page, ['application-card']);
  const sample = page.locator('#scope-a-sample');
  await expect(sample).toHaveCSS('width', '137px');
  await expect(sample).toHaveCSS('height', '72px');
  await expect(sample).toHaveCSS('background-color', 'rgb(18, 52, 86)');
  await sample.hover();
  await expect(sample).toHaveCSS('border-top-color', 'rgb(171, 205, 239)');
  await expect(sample).toHaveCSS('border-top-width', '2px');
  const after = await report(page);
  expect(after.button.status).toBe('rejected');
  expect(after.button.attempted_revision).toBe(next);
  expect(after.button.applied_revision).toBe(first);
  expect(after.button.drawn_revision).toBe(first);
  expect(after.button.computed).toEqual(before.button.computed);
  const png = PNG.sync.read(await page.getByTestId('utility-gpu').screenshot());
  const [x, y] = after.button.geometry;
  expect(pixel(png, x + 8, y + 8).slice(0, 3)).toEqual([18, 52, 86]);
  await page.mouse.move(0, 0);
  await expect(sample).not.toHaveCSS('border-top-color', 'rgb(171, 205, 239)');
  expect(errors).toEqual([]); expect(failed).toEqual([]);
  await info.attach('Custom variant DOM and retained GPU report', {body: JSON.stringify({before, after}, null, 2), contentType: 'application/json'});
  await page.screenshot({path: info.outputPath('custom-variant.png'), fullPage: true});
});

test('arbitrary properties with modifiers drive actual DOM and GPU pixels', async ({page}, info) => {
  await ready(page);
  const revision = await apply(page, ['[width:137px]/[1]', '[height:72px]/[1]', '[background-color:#123456]/100', '[color:#ffffff]/100']);
  const state = await drawn(page, revision);
  expect(state.button.status).toBe('applied');
  expect(state.button.geometry.slice(2)).toEqual([137, 72]);
  await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '137px');
  await expect(page.locator('#scope-a-sample')).toHaveCSS('background-color', 'rgb(18, 52, 86)');
  const png = PNG.sync.read(await page.getByTestId('utility-gpu').screenshot());
  const [x, y] = state.button.geometry;
  expect(pixel(png, x + 8, y + 8).slice(0, 3)).toEqual([18, 52, 86]);
  await page.screenshot({path: info.outputPath('arbitrary-property.png'), fullPage: true});
  await info.attach('Arbitrary property actual GPU report', {body: JSON.stringify(state, null, 2), contentType: 'application/json'});
});

test('mask CSS applies to DOM while GPU rejects its unsupported property and retains its drawn style', async ({page}, info) => {
  await ready(page);
  const first = await apply(page, ['w-[137px]', 'bg-[#123456]']);
  const before = await drawn(page, first);
  const next = await apply(page, ['w-[137px]', 'bg-[#123456]', 'mask-[linear-gradient(#123456,#abcdef)]']);
  await expect(page.locator('#scope-a-sample')).toHaveCSS('mask-image', 'linear-gradient(rgb(18, 52, 86), rgb(171, 205, 239))');
  const after = await report(page);
  expect(after.button.attempted_revision).toBe(next);
  expect(after.button.status).toBe('rejected');
  expect(after.button.applied_revision).toBe(first);
  expect(after.button.drawn_revision).toBe(first);
  expect(after.button.computed).toEqual(before.button.computed);
  expect(after.button.diagnostics.some((item: any) => item.property === 'mask-image')).toBe(true);
  await info.attach('Mask CSS with retained GPU report', {body: JSON.stringify(after, null, 2), contentType: 'application/json'});
});

test('strict GPU rejection retains the drawn style, partial reports skipped properties and deleting classes restores defaults', async ({page}) => {
  await ready(page);
  const defaults = (await report(page)).button.computed;
  const first = await apply(page, ['w-[137px]', 'bg-[#123456]']);
  const before = await drawn(page, first);
  const rejected = await apply(page, ['w-[179px]', 'bg-[#abcdef]', 'opacity-50']);
  const retained = await report(page);
  expect(retained.button.status).toBe('rejected');
  expect(retained.button.applied_revision).toBe(first);
  expect(retained.button.drawn_revision).toBe(first);
  expect(retained.button.computed).toEqual(before.button.computed);
  expect(retained.button.diagnostics.some((item: any) => item.property === 'opacity')).toBe(true);
  await apply(page, ['w-[179px]', 'bg-[#abcdef]', 'opacity-50'], [[], [], []], true);
  const partial = await drawn(page, rejected);
  expect(partial.button.status).toBe('partial');
  expect(partial.button.computed.width.value).toBe(179);
  expect(partial.button.computed.opacity).toBe(1);
  const restored = await apply(page, []);
  const reset = await drawn(page, restored);
  expect(reset.button.status).toBe('applied');
  expect(reset.button.computed).toEqual(defaults);
  await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '170px');
  await expect(page.locator('#scope-a-sample')).toHaveCSS('height', '36px');
});

test('GPU responds to pointer, keyboard focus-visible and disabled input without recompiling', async ({page}) => {
  await ready(page);
  const revision = await apply(page, ['w-[137px]', 'h-[72px]', 'bg-[#123456]', 'hover:bg-[#abcdef]', 'focus-visible:bg-[#fedcba]', 'active:bg-[#234567]', 'disabled:bg-[#999999]']);
  let state = await drawn(page, revision);
  const canvas = page.getByTestId('utility-gpu');
  const bounds = (await canvas.boundingBox())!;
  const [x, y, w, h] = state.button.geometry;
  await page.mouse.move(bounds.x + x + w / 2 + 1, bounds.y + y + h / 2 + 1);
  await expect.poll(async () => (await report(page)).button.state.hover).toBe(true);
  expect((await report(page)).button.computed.background.slice(0, 3)).toEqual([171/255, 205/255, 239/255]);
  await page.mouse.move(0, 0);
  await expect.poll(async () => (await report(page)).button.state.hover).toBe(false);
  await page.locator('#scope-a-sample').focus();
  await expect.poll(async () => (await report(page)).button.state.focus_visible).toBe(true);
  expect((await report(page)).button.computed.background.slice(0, 3)).toEqual([254/255, 220/255, 186/255]);
  await page.keyboard.down('Space');
  await expect.poll(async () => (await report(page)).button.state.active).toBe(true);
  await page.keyboard.up('Space');
  await expect(page.locator('#gpu-revision')).toContainText('1 clicks');
  await apply(page, ['w-[137px]', 'h-[72px]', 'bg-[#123456]', 'disabled:bg-[#999999]'], [[], [], []], false, true);
  await expect.poll(async () => (await report(page)).button.state.disabled).toBe(true);
  expect((await report(page)).button.state.active).toBe(false);
  await page.keyboard.press('Space');
  await expect(page.locator('#gpu-revision')).toContainText('1 clicks');
  expect((await report(page)).button.applied_revision).toBe(revision);
});

test('GPU media uses the browser viewport, and alpha color blocks match DOM pixels', async ({page}) => {
  await page.setViewportSize({width: 1000, height: 1000});
  await ready(page);
  const revision = await apply(page, ['w-[89px]', 'min-[768px]:w-[149px]', 'bg-[#123456]'], [[], [], ['bg-[#c82850]/50', 'opacity-50']]);
  let state = await drawn(page, revision);
  expect(state.button.geometry[2]).toBe(149);
  await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '149px');
  const png = PNG.sync.read(await page.getByTestId('utility-gpu').screenshot());
  const [x, y, w, h] = state.swatch.geometry;
  const gpu = pixel(png, x + w / 2 + 1, y + h / 2 + 1);
  const domPng = PNG.sync.read(await page.locator('#scope-a-swatch').screenshot());
  const dom = pixel(domPng, domPng.width / 2, domPng.height / 2);
  gpu.slice(0, 3).forEach((value, index) => expect(Math.abs(value - dom[index]), `alpha ${gpu}, ${dom}`).toBeLessThanOrEqual(2));
  await page.setViewportSize({width: 390, height: 844});
  await page.getByTestId('utility-gpu').scrollIntoViewIfNeeded();
  await expect.poll(async () => (await report(page)).button.geometry[2]).toBe(89);
  await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '89px');
  expect((await report(page)).button.applied_revision).toBe(revision);
});

test('GPU applies text resources, row layout, shadows and rings from compiler bindings', async ({page}) => {
  await page.setViewportSize({width: 1280, height: 1000});
  await ready(page);
  const revision = await apply(page, ['w-[100px]', 'h-[60px]', 'bg-[#123456]', 'ring-[3px]', 'ring-[#abcdef]'],
    [['flex', 'flex-row', 'gap-[11px]', 'p-[9px]', 'items-center'], ["font-['Liberation_Mono']", 'text-[20px]', 'leading-[28px]', 'tracking-[0.05em]'], []]);
  const state = await drawn(page, revision, 'text');
  expect(state.text.status).toBe('applied');
  expect(state.text.computed.font.family).toBe('Liberation Mono');
  expect(state.text.computed.font_size_px).toBe(20);
  expect(state.text.computed.line_height.value).toBe(28);
  expect(state.text.computed.letter_spacing_em).toBe(.05);
  expect(state.container.computed.gap).toEqual([11, 11]);
  expect(state.container.computed.flow).toBe('row');
  expect(state.text.geometry[0] - state.button.geometry[0] - state.button.geometry[2]).toBeCloseTo(11);
  expect(state.swatch.geometry[0] - state.text.geometry[0] - state.text.geometry[2]).toBeCloseTo(11);
  expect(state.button.computed.shadows.some((shadow: any) => shadow.spread === 3)).toBe(true);
  await expect(page.locator('#scope-a-text')).toHaveCSS('font-family', '"Liberation Mono"');
  await expect(page.locator('#scope-a-text')).toHaveCSS('font-size', '20px');
  const png = PNG.sync.read(await page.getByTestId('utility-gpu').screenshot());
  const [x, y, w] = state.button.geometry;
  const ring = pixel(png, x + w / 2 + 1, y - 1);
  [171, 205, 239].forEach((value, index) => expect(Math.abs(ring[index] - value)).toBeLessThanOrEqual(3));
});

test('GPU restores its latest committed programs after a real WebGL context loss', async ({page}) => {
  await ready(page);
  const first = await apply(page, ['w-[137px]', 'bg-[#123456]']);
  await drawn(page, first);
  await page.getByTestId('utility-gpu').evaluate((canvas: HTMLCanvasElement) => {
    const gl = canvas.getContext('webgl2')!;
    const extension = gl.getExtension('WEBGL_lose_context')!;
    (window as any).__utility_loss = extension; extension.loseContext();
  });
  await expect(page.locator('#gpu-status')).toHaveText('Restoring GPU…');
  const next = await page.evaluate(async () => (await (window as any).__utility_lab.gpuApply('scope-a', [[], ['w-[179px]', 'bg-[#abcdef]'], [], []])).revision);
  await page.evaluate(() => { (window as any).__utility_loss.restoreContext(); delete (window as any).__utility_loss; });
  await expect(page.locator('#gpu-status')).toHaveText('GPU ready');
  const state = await drawn(page, next);
  expect(state.button.computed.width.value).toBe(179);
  expect(state.button.computed.background.slice(0, 3)).toEqual([171/255, 205/255, 239/255]);
  expect(await page.getByTestId('utility-gpu').count()).toBe(1);
});

test('terminal GPU initialization failure explains recovery while DOM editing remains usable', async ({page}, info) => {
  await page.addInitScript(() => {
    const original = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function(type: any, ...args: any[]) {
      if (type === 'webgl2') return null;
      return original.apply(this, [type, ...args] as any);
    } as any;
  });
  await page.goto('./');
  await expect(page.locator('#status')).toHaveAttribute('data-status', 'ready');
  await expect(page.locator('#gpu-status')).toContainText('GPU unavailable: no WebGL2 context');
  await expect(page.locator('#gpu-status')).toContainText('Copy your class inputs, then reload');
  await page.locator('#classes').fill('w-[179px] bg-[#abcdef]');
  await page.locator('#apply').click();
  await expect(page.locator('#status')).toContainText('DOM styles installed.');
  await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '179px');
  await page.screenshot({path: info.outputPath('gpu-terminal-failure.png'), fullPage: true});
});

test('all non-button GPU boundaries are visible and the desktop comparison frames align', async ({page}, info) => {
  await ready(page);
  await apply(page, ['w-[137px]', 'bg-[#123456]'], [['opacity-50'], ['bg-[#abcdef]', 'opacity-50'], ['grid']]);
  await expect(page.locator('#gpu-results')).toContainText('Container: rejected');
  await expect(page.locator('#gpu-results')).toContainText('Text: rejected');
  await expect(page.locator('#gpu-results')).toContainText('Color block: rejected');
  await expect(page.locator('#gpu-warning')).toContainText('opacity-50 (opacity)');
  await expect(page.locator('#gpu-warning')).toContainText('grid (display)');
  await expect(page.locator('#gpu-warning')).toContainText('Remove the class');
  const dom = (await page.locator('#scope-a.preview').boundingBox())!;
  const gpu = (await page.getByTestId('utility-gpu').boundingBox())!;
  expect(Math.abs(dom.y - gpu.y)).toBeLessThanOrEqual(1);
  await page.screenshot({path: info.outputPath('gpu-boundaries.png'), fullPage: true});
  await apply(page, ['w-[137px]', 'bg-[#123456]'], [['opacity-50'], ['bg-[#abcdef]', 'opacity-50'], ['grid']], true);
  await expect(page.locator('#gpu-results')).toContainText('Container: partial');
  await expect(page.locator('#gpu-results')).toContainText('Text: partial');
  await expect(page.locator('#gpu-results')).toContainText('Color block: partial');
});

test('live ThemeScope and ThemeBoundary update colors, dark conditions and host rem without recompiling', async ({page}, info) => {
  await page.setViewportSize({width: 1000, height: 900});
  await ready(page);
  const baseline = (await report(page)).button.computed;
  const revision = await apply(page, ['w-[5rem]', 'bg-(--primary)', 'text-(--primary-foreground)', 'dark:border-2', 'dark:border-[#123456]', 'min-[60rem]:h-[73px]'], [['gap-[1rem]'], ['text-(--foreground)'], ['bg-(--primary)']]);
  await drawn(page, revision);
  await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '80px');
  expect((await report(page)).button.computed.height.value).toBe(73);
  const installed = await page.evaluate(() => (window as any).__utility_lab.report('scope-a'));
  const sibling = await page.locator('#scope-b-sample').evaluate(node => getComputedStyle(node).backgroundColor);
  await page.emulateMedia({colorScheme: 'dark'});
  await page.evaluate(() => {
    document.documentElement.style.fontSize = '20px';
    (window as any).__utility_lab.theme('scope-a', true, 20, {primary: '#abcdef'});
  });
  await expect(page.locator('#scope-a')).toHaveAttribute('data-theme', 'dark');
  await expect(page.getByTestId('utility-theme-boundary')).toHaveCSS('--primary', 'rgb(171 205 239)');
  await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '100px');
  await expect(page.locator('#scope-a-sample')).toHaveCSS('background-color', 'rgb(171, 205, 239)');
  await expect.poll(async () => (await report(page)).button.computed.background).toEqual([171 / 255, 205 / 255, 239 / 255, 1]);
  await expect.poll(async () => (await report(page)).button.computed.width.value).toBe(100);
  expect((await report(page)).button.computed.height.value).toBe(73);
  expect((await report(page)).button.computed.border_widths).toEqual([2, 2, 2, 2]);
  expect((await report(page)).container.computed.gap).toEqual([20, 20]);
  await expect(page.locator('#scope-b-sample')).toHaveCSS('background-color', sibling);
  expect(await page.evaluate(() => (window as any).__utility_lab.report('scope-a'))).toEqual(installed);
  const retained = (await report(page)).button.computed;
  const rejected = await page.evaluate(() => {
    try { (window as any).__utility_lab.theme('scope-a', false, 16, {radius: 'invalid'}); return false; }
    catch { return true; }
  });
  expect(rejected).toBe(true);
  expect((await report(page)).button.computed).toEqual(retained);
  const actual = PNG.sync.read(await page.getByTestId('utility-gpu').screenshot());
  const bounds = (await report(page)).button.geometry;
  expect(pixel(actual, bounds[0] + 5, bounds[1] + 5)).toEqual([171, 205, 239, 255]);
  await info.attach('Theme actual drawn report', {body: JSON.stringify(await report(page), null, 2), contentType: 'application/json'});
  await page.screenshot({path: info.outputPath('gpu-theme-boundary.png'), fullPage: true});
  await page.evaluate(() => (window as any).__utility_lab.theme('scope-a', true, 20));
  await expect(page.getByTestId('utility-theme-boundary')).not.toHaveAttribute('data-rustify-theme-runtime');
  await expect.poll(async () => (await report(page)).button.computed.background).not.toEqual(retained.background);
  await page.emulateMedia({colorScheme: 'light'});
  await page.evaluate(() => {
    document.documentElement.style.fontSize = '';
    (window as any).__utility_lab.theme('scope-a', false, 16);
  });
  await expect(page.locator('#scope-a')).toHaveAttribute('data-theme', 'light');
  const restored = await apply(page, []);
  await drawn(page, restored);
  expect((await report(page)).button.computed.background).toEqual(baseline.background);
  expect((await report(page)).button.computed.padding).toEqual(baseline.padding);
});
