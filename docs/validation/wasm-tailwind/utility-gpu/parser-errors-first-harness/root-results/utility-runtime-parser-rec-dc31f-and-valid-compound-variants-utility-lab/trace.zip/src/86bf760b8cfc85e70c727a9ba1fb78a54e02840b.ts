import { test, expect } from '@playwright/test';

async function ready(page: any) {
    await page.goto('./');
    await expect(page.locator('#status')).toHaveAttribute('data-status', 'ready');
}

test('parser recovery preserves authored important values and valid compound variants', async ({page}, info) => {
    const errors: string[] = [], failed: string[] = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
    page.on('requestfailed', request => failed.push(request.url()));
    await ready(page);
    const result = await page.evaluate(async () => {
        const api = (window as any).__utility_lab;
        api.dispose('scope-a');
        api.mount('scope-a', 10000, '@tailwind utilities; .sample { width:137px!important ignored; background-color:#123456; }');
        const classes = ['[_]:block', 'data-foo[bar]:block', 'group-data-[state=open]:w-[159px]!'];
        const report = await api.ensure('scope-a', classes);
        const frame = document.getElementById('scope-a-frame')!;
        frame.classList.add('group');
        const sample = document.getElementById('scope-a-sample')!;
        sample.className = `sample ${classes.join(' ')}`;
        frame.setAttribute('data-state', 'closed');
        const closed = getComputedStyle(sample).width;
        frame.setAttribute('data-state', 'open');
        const open = getComputedStyle(sample).width;
        frame.setAttribute('data-state', 'closed');
        return {report, closed, open, restored: getComputedStyle(sample).width,
            background: getComputedStyle(sample).backgroundColor,
            otherWidth: getComputedStyle(document.getElementById('scope-b-sample')!).width};
    });
    expect(result.report.unsupported).toEqual([]);
    expect(result.report.rejected.map((item: any) => item.candidate).sort()).toEqual(['[_]:block', 'data-foo[bar]:block']);
    expect(result.report.admitted).toEqual(['group-data-[state=open]:w-[159px]!']);
    expect(result.report.css).not.toContain('ignored');
    expect(result.closed).toBe('137px');
    expect(result.open).toBe('159px');
    expect(result.restored).toBe('137px');
    expect(result.background).toBe('rgb(18, 52, 86)');
    expect(result.otherWidth).toBe('170px');
    expect(errors).toEqual([]); expect(failed).toEqual([]);
    await info.attach('Parser browser values', {body: JSON.stringify(result, null, 2), contentType: 'application/json'});
});

test('structural spacing, container and line clamp keep their actual browser semantics', async ({page}, info) => {
    await ready(page);
    const result = await page.evaluate(async () => {
        const api = (window as any).__utility_lab;
        const classes = ['border-separate', 'border-spacing-[12px]', 'flex', 'space-x-[9px]',
            'space-x-reverse', 'line-clamp-2', '@container/probe'];
        const report = await api.ensure('scope-a', classes);
        const root = document.getElementById('scope-a')!;
        const table = document.createElement('table');
        table.className = 'border-separate border-spacing-[12px]';
        table.innerHTML = '<tbody><tr><td>one</td><td>two</td></tr></tbody>';
        const siblings = document.createElement('div');
        siblings.className = 'flex space-x-[9px] space-x-reverse';
        siblings.innerHTML = '<span>one</span><span>two</span><span>three</span>';
        const container = document.createElement('div');
        container.className = '@container/probe';
        const clamp = document.createElement('p');
        clamp.className = 'line-clamp-2';
        clamp.textContent = 'Browser utility checks';
        container.append(clamp);
        root.append(table, siblings, container);
        const margins = Array.from(siblings.children).map(child => {
            const style = getComputedStyle(child);
            return [style.marginInlineStart, style.marginInlineEnd];
        });
        const containerStyle = getComputedStyle(container), clampStyle = getComputedStyle(clamp);
        return {revision: report.revision, pending: report.unsupported, spacing: getComputedStyle(table).borderSpacing,
            margins, containerType: containerStyle.containerType, containerName: containerStyle.containerName,
            lineClamp: clampStyle.webkitLineClamp, overflow: clampStyle.overflow, css: report.css};
    });
    expect(result.pending).toEqual([]);
    expect(result.spacing).toBe('12px');
    expect(result.margins).toEqual([['9px', '0px'], ['9px', '0px'], ['0px', '0px']]);
    expect(result.containerType).toBe('inline-size');
    expect(result.containerName).toBe('probe');
    expect(result.lineClamp).toBe('2');
    expect(result.overflow).toBe('hidden');
    expect(result.css).not.toContain('--tw-sort');
    await info.attach('Structural browser values', {body: JSON.stringify(result, null, 2), contentType: 'application/json'});
});

test('SDK ensure installs scanner-free CSS, coalesces requests and isolates independent scopes', async ({ page }, testInfo) => {
    const errors: string[] = [];
    const failed: string[] = [];
    const paths: string[] = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('requestfailed', request => failed.push(request.url()));
    page.on('request', request => paths.push(request.url()));
    await ready(page);
    const result = await page.evaluate(async () => {
        const api = (window as any).__utility_lab;
        const violations: string[] = [];
        document.addEventListener('securitypolicyviolation', event => violations.push(event.violatedDirective));
        const first = await Promise.all([
            api.ensure('scope-a', ['w-[137px]']),
            api.ensure('scope-a', ['bg-[#123456]', 'w-[137px]']),
        ]);
        const sample = document.getElementById('scope-a-sample')!;
        sample.className = 'sample w-[137px] bg-[#123456]';
        const style = getComputedStyle(sample);
        const width = style.width;
        const color = style.backgroundColor;
        const initial = api.report('scope-a');
        const repeated = await api.ensure('scope-a', ['w-[137px]']);
        const other = await api.ensure('scope-b', ['w-[93px]', 'bg-[#abcdef]']);
        const second = document.getElementById('scope-b-sample')!;
        second.className = 'sample w-[93px] bg-[#abcdef]';
        const outside = document.getElementById('outside')!;
        const outsideColor = getComputedStyle(outside).backgroundColor;
        const otherColor = getComputedStyle(second).backgroundColor;
        const sheetCount = document.adoptedStyleSheets.length;
        const css = api.report('scope-a').css;
        api.dispose('scope-a');
        return { first: first.map((report: any) => report.revision), revision: initial.revision,
            repeatedRevision: repeated.revision, width, color, otherColor, outsideColor,
            otherRevision: other.revision, sheetCount, remainingSheets: document.adoptedStyleSheets.length,
            remainingColor: getComputedStyle(second).backgroundColor, violations, css };
    });
    expect(result.first).toEqual([1, 1]);
    expect(result.width).toBe('137px');
    expect(result.color).toBe('rgb(18, 52, 86)');
    expect(result.otherColor).toBe('rgb(171, 205, 239)');
    expect(result.outsideColor).toBe('rgba(0, 0, 0, 0)');
    expect(result.repeatedRevision).toBe(result.revision);
    expect(result.remainingSheets).toBe(result.sheetCount - 1);
    expect(result.remainingColor).toBe(result.otherColor);
    expect(result.violations).toEqual([]);
    expect(errors).toEqual([]);
    expect(failed).toEqual([]);
    expect(paths.some(path => path.includes('/extractor/'))).toBe(false);
    await testInfo.attach('SDK committed stylesheet', { body: JSON.stringify(result, null, 2), contentType: 'application/json' });
});

test('controls apply classes and fit desktop and mobile', async ({ page }, testInfo) => {
    await ready(page);
    await page.locator('#classes').fill('w-[137px] bg-[#123456] h-[72px] text-[#ffffff] rounded-[8px]');
    await page.locator('#apply').click();
    await expect(page.locator('#status')).toContainText('DOM styles installed. Revision 1.');
    await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '137px');
    await expect(page.locator('#scope-a-sample')).toHaveCSS('background-color', 'rgb(18, 52, 86)');
    await expect(page.locator('#scope-a-sample')).toHaveCSS('color', 'rgb(255, 255, 255)');
    await page.screenshot({ path: testInfo.outputPath('desktop.png'), fullPage: true });
    await page.setViewportSize({ width: 390, height: 844 });
    await page.evaluate(async () => {
        await document.fonts.ready;
        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await page.screenshot({ path: testInfo.outputPath('mobile.png'), fullPage: true });
});

test('nested owners stop outer rules and disposal removes the owned stylesheet', async ({ page }) => {
    await ready(page);
    const result = await page.evaluate(async () => {
        const api = (window as any).__utility_lab;
        api.mount('scope-a-nested');
        const nested = document.getElementById('scope-a-nested-sample')!;
        const baseline = getComputedStyle(nested).backgroundColor;
        await api.ensure('scope-a', ['w-[137px]', 'bg-[#123456]']);
        nested.className = 'sample w-[137px] bg-[#123456]';
        const unstyled = getComputedStyle(nested).backgroundColor;
        await api.ensure('scope-a-nested', ['bg-[#abcdef]']);
        nested.className = 'sample bg-[#abcdef]';
        const styled = getComputedStyle(nested).backgroundColor;
        api.dispose('scope-a-nested');
        return { baseline, unstyled, styled, owner: document.getElementById('scope-a-nested')!.hasAttribute('data-rustify-style-owner') };
    });
    expect(result.unstyled).toBe(result.baseline);
    expect(result.unstyled).not.toBe('rgb(18, 52, 86)');
    expect(result.styled).toBe('rgb(171, 205, 239)');
    expect(result.owner).toBe(false);
});

test('classList changes and newly added subtrees compile through the bounded observer without scanner', async ({ page }) => {
    await ready(page);
    await page.evaluate(async () => {
        const api = (window as any).__utility_lab;
        await api.ensure('scope-a', []);
        document.getElementById('scope-a-sample')!.classList.add('w-[151px]');
    });
    await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '151px');
    await page.evaluate(() => {
        const child = document.createElement('div');
        child.id = 'observer-child';
        child.className = 'bg-[#abcdef] h-[37px]';
        document.getElementById('scope-a-sample')!.append(child);
    });
    await expect(page.locator('#observer-child')).toHaveCSS('background-color', 'rgb(171, 205, 239)');
    await expect(page.locator('#observer-child')).toHaveCSS('height', '37px');
    const unchanged = await page.evaluate(async () => {
        const api = (window as any).__utility_lab;
        const before = api.report('scope-a').revision;
        const sample = document.getElementById('scope-a-sample')!;
        sample.classList.remove('w-[151px]'); sample.classList.add('w-[151px]');
        await new Promise(resolve => setTimeout(resolve, 50));
        return { before, after: api.report('scope-a').revision };
    });
    expect(unchanged.after).toBe(unchanged.before);
});

test('scoped relation variants and arbitrary selectors retain conditional matching', async ({ page }, testInfo) => {
    await ready(page);
    const result = await page.evaluate(async () => {
        const api = (window as any).__utility_lab;
        const classes = ['w-[89px]', 'h-[11px]', 'group-data-[state=open]:bg-[#123456]',
            'peer-data-[state=open]:h-[37px]', '[&>span]:w-[63px]', 'p-[7px]'];
        const report = await api.ensure('scope-a', classes);
        const root = document.getElementById('scope-a-sample')!;
        root.className = 'group p-[7px]';
        const flag = document.createElement('div');
        flag.className = 'peer';
        const child = document.createElement('div');
        child.className = 'w-[89px] h-[11px] group-data-[state=open]:bg-[#123456] peer-data-[state=open]:h-[37px] [&>span]:w-[63px]';
        const span = document.createElement('span');
        span.style.display = 'block';
        child.append(span);
        root.append(flag, child);
        const before = { color: getComputedStyle(child).backgroundColor, height: getComputedStyle(child).height };
        root.dataset.state = 'open';
        flag.dataset.state = 'open';
        const after = { color: getComputedStyle(child).backgroundColor, height: getComputedStyle(child).height };
        const other = document.getElementById('scope-b-sample')!;
        other.className = child.className;
        const outside = document.getElementById('outside')!;
        outside.className = child.className;
        const isolated = [other, outside].map(element => getComputedStyle(element).backgroundColor);
        root.dataset.state = 'closed';
        flag.dataset.state = 'closed';
        return { before, after, isolated, padding: getComputedStyle(root).padding,
            spanWidth: getComputedStyle(span).width, restoredHeight: getComputedStyle(child).height,
            unsupported: report.unsupported, css: report.css };
    });
    expect(result.before).toEqual({ color: 'rgba(0, 0, 0, 0)', height: '11px' });
    expect(result.after).toEqual({ color: 'rgb(18, 52, 86)', height: '37px' });
    expect(result.isolated).toEqual(['rgba(0, 0, 0, 0)', 'rgba(0, 0, 0, 0)']);
    expect(result.padding).toBe('7px');
    expect(result.spanWidth).toBe('63px');
    expect(result.restoredHeight).toBe('11px');
    expect(result.unsupported).toEqual([]);
    await testInfo.attach('scoped relation variant results', { body: JSON.stringify(result, null, 2), contentType: 'application/json' });
});

test('arbitrary responsive conditions follow the browser viewport at both sizes', async ({ page }, testInfo) => {
    await ready(page);
    await page.setViewportSize({ width: 1000, height: 844 });
    const report = await page.evaluate(async () => {
        const api = (window as any).__utility_lab;
        const classes = ['w-[89px]', 'h-[11px]', 'min-[600px]:w-[149px]', 'max-[600px]:h-[47px]'];
        const report = await api.ensure('scope-a', classes);
        document.getElementById('scope-a-sample')!.className = classes.join(' ');
        return report;
    });
    await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '149px');
    await expect(page.locator('#scope-a-sample')).toHaveCSS('height', '11px');
    await page.setViewportSize({ width: 390, height: 844 });
    await expect(page.locator('#scope-a-sample')).toHaveCSS('width', '89px');
    await expect(page.locator('#scope-a-sample')).toHaveCSS('height', '47px');
    expect(report.unsupported).toEqual([]);
    await testInfo.attach('responsive prepared report', { body: JSON.stringify(report, null, 2), contentType: 'application/json' });
});

test('color alpha and scoped placeholder selectors retain their browser semantics', async ({ page }, testInfo) => {
    await ready(page);
    const result = await page.evaluate(async () => {
        const api = (window as any).__utility_lab;
        const classes = ['bg-[#123456]/50', 'text-[#abcdef]/[.35]', 'border-[#fedcba]/25', 'placeholder-[#123456]/50'];
        const report = await api.ensure('scope-a', classes);
        const sample = document.getElementById('scope-a-sample')!;
        sample.className = classes.slice(0, 3).join(' ');
        const input = document.createElement('input');
        input.placeholder = 'Color sample';
        input.className = classes[3];
        sample.append(input);
        const outside = document.createElement('input');
        outside.placeholder = 'Outside scope';
        outside.className = classes[3];
        document.getElementById('outside')!.append(outside);
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = 1;
        const context = canvas.getContext('2d')!;
        function pixel(color: string) {
            context.clearRect(0, 0, 1, 1);
            context.fillStyle = color;
            context.fillRect(0, 0, 1, 1);
            return Array.from(context.getImageData(0, 0, 1, 1).data);
        }
        const style = getComputedStyle(sample);
        return { background: pixel(style.backgroundColor), text: pixel(style.color), border: pixel(style.borderTopColor),
            placeholder: pixel(getComputedStyle(input, '::placeholder').color),
            outside: pixel(getComputedStyle(outside, '::placeholder').color),
            unsupported: report.unsupported, css: report.css };
    });
    for (const [actual, expected] of [[result.background, [18, 52, 86, 128]],
        [result.text, [171, 205, 239, 89]], [result.border, [254, 220, 186, 64]],
        [result.placeholder, [18, 52, 86, 128]]] as const) {
        actual.forEach((value, index) => expect(Math.abs(value - expected[index])).toBeLessThanOrEqual(2));
    }
    expect(result.outside).not.toEqual(result.placeholder);
    expect(result.unsupported).toEqual([]);
    await testInfo.attach('color alpha and placeholder results', { body: JSON.stringify(result, null, 2), contentType: 'application/json' });
});
